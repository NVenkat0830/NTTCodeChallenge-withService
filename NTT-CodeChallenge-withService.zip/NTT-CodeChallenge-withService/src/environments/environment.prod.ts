/*Configured deno Rest API URL's for production*/
export const environment = {
  production: false,
  server: 'http://localhost:8080/enrollees'
};
