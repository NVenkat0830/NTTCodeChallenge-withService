import { Component, OnInit } from '@angular/core';
//import enrolles from '../datafiles/enrollees.json';
import { EnrolleeDataService } from '../enrollee-data.service';

@Component({
  selector: 'app-enrolles',
  templateUrl: './enrolles.component.html',
  styleUrls: ['./enrolles.component.scss']
})
export class EnrollesComponent implements OnInit {

  //enrolleesData:{id:string, name:string, status:boolean, dob:string}[]= enrolles;
  enrolleesData=[];
  title = 'NTT Code Challenge';
  edit: any = {};

  constructor(public enrolledataService: EnrolleeDataService) {
    this.enrolleesData.forEach((el, i) => {
      this.edit[i] = false;
    });    
   }

  ngOnInit(): void {
    this.enrolledataService
        .getEnrolleeData()
        .subscribe((data: any[]) =>  {              
              console.log("enrolees data",data);
              this.enrolleesData = data;
        },
        error => () => {
              console.log("Error Occured")
        });
  }

  /*By using below event click, making Edit variable value to False to dispaly input field and radio buttons to edit the name and active field values.*/
  getCurrentEnroll(event, data, i){
    this.edit[i] = true;    
  }

   /*By using below event click, making Edit variable value to False to dispaly updated values and hiding the input/radio buttons.*/
  saveCurrentEnroll(event, data, i){
    this.edit[i] = false;
  }

}
