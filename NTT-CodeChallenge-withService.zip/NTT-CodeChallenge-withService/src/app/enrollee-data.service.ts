import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable ,  throwError as _throw } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})

export class EnrolleeDataService {

  constructor(private http:HttpClient) { }

  /*getting data from service which is declared in the environment.ts file*/

  getEnrolleeData(): Observable<any[]> {
      return this.http
        .get<any[]>(`${environment.server}`)
        .pipe(catchError((error: any) => _throw(error)));
    }

    /* we can able to give API URL's directly as well like below commented code*/
  /*  getEnrolleeData(): Observable<any[]> {
      return this.http
        .get<any[]>("http://localhost:8080/enrollees")
        .pipe(catchError((error: any) => _throw(error)));
    }*/

}
