import { TestBed } from '@angular/core/testing';

import { EnrolleeDataService } from './enrollee-data.service';

describe('EnrolleeDataService', () => {
  let service: EnrolleeDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EnrolleeDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
